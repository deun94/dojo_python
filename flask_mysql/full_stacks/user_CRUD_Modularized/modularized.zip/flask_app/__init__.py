from flask import Flask
app = Flask(__name__)
app.sercret_key = "sakdj;flkdsjfk"